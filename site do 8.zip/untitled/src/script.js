const WHATSAPP = "5511997465287";
const INSTAGRAM = "https://instagram.com/_kingphones_";

function whatsappLink(product = "") {

  let message = "Olá! Vim pelo site da KingPhones.";

  if (product) {
    message += " Tenho interesse no " + product + ".";
  }

  return (
    "https://wa.me/" +
    WHATSAPP +
    "?text=" +
    encodeURIComponent(message)
  );
}


/* LINKS */

document.getElementById("topWhatsapp").href =
  whatsappLink();

document.getElementById("heroWhatsapp").href =
  whatsappLink();

document.getElementById("ctaWhatsapp").href =
  whatsappLink();

document.getElementById("footerWhatsapp").href =
  whatsappLink();

document.getElementById("floatingWhatsapp").href =
  whatsappLink();

document.getElementById("footerInstagram").href =
  INSTAGRAM;


/* PREÇOS */

document.querySelectorAll(".capacidade").forEach(select => {

  select.addEventListener("change", function () {

    const precoBase =
      Number(this.dataset.preco);

    let adicional = 0;

    if (this.value === "256") {
      adicional = 200;
    }

    if (this.value === "512") {
      adicional = 400;
    }

    if (this.value === "1tb") {
      adicional = 600;
    }

    const novoPreco =
      precoBase + adicional;

    const produto =
      this.closest(".produto");

    produto.querySelector(
      ".preco strong"
    ).textContent =
      novoPreco.toLocaleString(
        "pt-BR",
        {
          style: "currency",
          currency: "BRL"
        }
      );
  });

});


/* WHATSAPP DO PRODUTO */

document.querySelectorAll(".btn-produto")
.forEach(botao => {

  botao.addEventListener("click", function () {

    const produto =
      this.closest(".produto");

    const nome =
      produto.dataset.nome;

    const capacidade =
      produto.querySelector(
        ".capacidade"
      ).value;

    const armazenamento =
      capacidade === "1tb"
        ? "1 TB"
        : capacidade + " GB";

    const mensagem =
      nome +
      " " +
      armazenamento;

    window.open(
      whatsappLink(mensagem),
      "_blank"
    );

  });

});


/* FILTROS */

const filtros =
  document.querySelectorAll(".filtro");

const produtos =
  document.querySelectorAll(".produto");

filtros.forEach(filtro => {

  filtro.addEventListener("click", function () {

    filtros.forEach(f =>
      f.classList.remove("ativo")
    );

    this.classList.add("ativo");

    const selecionado =
      this.dataset.filter;

    produtos.forEach(produto => {

      if (
        selecionado === "todos" ||
        produto.dataset.modelo === selecionado
      ) {

        produto.style.display = "";

      } else {

        produto.style.display = "none";

      }

    });

  });

});


/* BUSCA */

document
  .getElementById("search")
  .addEventListener("input", function () {

    const termo =
      this.value.toLowerCase();

    produtos.forEach(produto => {

      const nome =
        produto.dataset.nome.toLowerCase();

      produto.style.display =
        nome.includes(termo)
          ? ""
          : "none";

    });

  });